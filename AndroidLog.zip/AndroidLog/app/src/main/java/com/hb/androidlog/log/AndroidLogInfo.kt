package com.hb.androidlog.log

data class AndroidLogInfo(var dateTime: String,var title: String,var message: String)