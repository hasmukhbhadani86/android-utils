package com.hb.androidlog

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.hb.androidlog.log.AndroidLog
import com.hb.androidlog.log.AndroidLogInfo
import com.hb.androidlog.log.FileUtils
import kotlinx.android.synthetic.main.activity_main.*
import java.io.File
import java.io.IOException
import java.util.*

class MainActivity : AppCompatActivity()
{
    var mAndroidLogList: ArrayList<AndroidLogInfo> = arrayListOf()

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        AndroidLog.e("Main Activity,","Test message",true)

        btnViewLog.setOnClickListener {

            mAndroidLogList.addAll(FileUtils.readAndroidLogFile().reversed())

            val builder = StringBuilder()

            mAndroidLogList.forEach { androidLogInfo: AndroidLogInfo ->
                builder.append("\n")
                builder.append(androidLogInfo.message)
                builder.append("\n")
            }
            Toast.makeText(this,builder.toString(),Toast.LENGTH_LONG).show()
        }

        btnSendLog.setOnClickListener {

            try
            {
                val emailIntent = Intent(Intent.ACTION_SEND)
                emailIntent.type = "text/plain"
                emailIntent.putExtra(
                    Intent.EXTRA_SUBJECT, getString(R.string.app_name) + " " + " Log File Attachment of Date " +Date())

               val logFile = File(AndroidLog.getLogFilePath())
                if (logFile.exists() || logFile.canRead())
                {
                    val uri = Uri.fromFile(logFile)
                    emailIntent.putExtra(Intent.EXTRA_STREAM, uri)
                    startActivity(Intent.createChooser(emailIntent, "Pick an Email provider"))
                }

            }
            catch (ex: IOException)
            {
                AndroidLog.e("", "Zip file Exception", ex)
            }

        }

    }
}
