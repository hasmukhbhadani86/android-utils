package com.hb.androidlog.log

import java.io.BufferedReader
import java.io.File
import java.io.FileInputStream
import java.io.InputStreamReader
import java.util.*

object FileUtils
{
    val BUFFER_SIZE = 2048

    fun readAndroidLogFile(): ArrayList<AndroidLogInfo>
    {
        val logFile = File(AndroidLog.getLogFilePath())
        val mLogList: ArrayList<AndroidLogInfo> = arrayListOf()

        if (logFile != null && logFile.exists())
        {
            val origin = BufferedReader(InputStreamReader(FileInputStream(logFile)), BUFFER_SIZE)
            try
            {
                var data = origin.readLine()
                while (data != null)
                {
                    if (data != null)
                    {
                        var logData = data.split("\t\t")

                        logData = logData.map { log: String? -> log!!.removeSurrounding("[", "]") }

                        mLogList.add(AndroidLogInfo(logData[0], logData[1], logData[2]))
                    }
                    data = origin.readLine()
                }
            }
            finally
            {
                origin.close()
            }
        }

        return mLogList
    }
}