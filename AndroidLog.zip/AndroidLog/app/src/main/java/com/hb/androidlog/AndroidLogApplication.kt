package com.hb.androidlog

import android.app.Application
import com.hb.androidlog.log.AndroidLog
import com.hb.androidlog.log.AndroidLogConfig


class AndroidLogApplication : Application()
{
    override fun onCreate()
    {
        super.onCreate()
        initLogConfig()
    }

    private fun initLogConfig()
    {
        /*create for Log*/
        val androidLogConfig = AndroidLogConfig()
        androidLogConfig.setIsLogEnabled(true)
        androidLogConfig.setIsWriteInFile(true)
        androidLogConfig.setLogSize(10000)
        AndroidLog.create(androidLogConfig, this)

        AndroidLog.e("", "Init Log Config")
    }
}